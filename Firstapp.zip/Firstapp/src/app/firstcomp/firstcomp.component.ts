import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstcomp',
  templateUrl: './firstcomp.component.html',
  styleUrls: ['./firstcomp.component.css']
})
export class FirstcompComponent implements OnInit {
title="My First Component";
  constructor() { }

  ngOnInit(): void {
  }

}
