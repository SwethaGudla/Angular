import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeecompComponent } from './employeecomp/employeecomp.component';
import { ForgotpasscompComponent } from './forgotpasscomp/forgotpasscomp.component';
import { LogincompComponent } from './logincomp/logincomp.component';
import { RegiscompComponent } from './regiscomp/regiscomp.component';
import { StudentcompComponent } from './studentcomp/studentcomp.component';


const routes: Routes = [

  {
    path:'student',component:StudentcompComponent
  },
  {
    path:'employee',component:EmployeecompComponent
  },
  {
    path:'login',component:LogincompComponent
  },
  {
    path:'register',component:RegiscompComponent
  },
  {
    path:'pass',component:ForgotpasscompComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
