import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logincomp',
  templateUrl: './logincomp.component.html',
  styleUrls: ['./logincomp.component.css']
})
export class LogincompComponent implements OnInit {
  constructor() { 
  }

  ngOnInit() {
  }

}



