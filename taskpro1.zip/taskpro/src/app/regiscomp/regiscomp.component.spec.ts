import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegiscompComponent } from './regiscomp.component';

describe('RegiscompComponent', () => {
  let component: RegiscompComponent;
  let fixture: ComponentFixture<RegiscompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegiscompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegiscompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
