import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regiscomp',
  templateUrl: './regiscomp.component.html',
  styleUrls: ['./regiscomp.component.css']
})
export class RegiscompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
