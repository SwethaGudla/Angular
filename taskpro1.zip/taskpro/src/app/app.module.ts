import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeecompComponent } from './employeecomp/employeecomp.component';
import { StudentcompComponent } from './studentcomp/studentcomp.component';
import { LogincompComponent } from './logincomp/logincomp.component';
import { RegiscompComponent } from './regiscomp/regiscomp.component';
import { ForgotpasscompComponent } from './forgotpasscomp/forgotpasscomp.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    EmployeecompComponent,
    StudentcompComponent,
    LogincompComponent,
    RegiscompComponent,
    ForgotpasscompComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
