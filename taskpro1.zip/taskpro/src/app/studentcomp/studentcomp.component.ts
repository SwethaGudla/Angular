import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentcomp',
  templateUrl: './studentcomp.component.html',
  styleUrls: ['./studentcomp.component.css']
})
export class StudentcompComponent implements OnInit {

  constructor() { }
  s_id:number=12;
  s_name:string="suraj123"
  s_phno:string='suraj123@gmail.com';
  s_address:string="Vanasthalipuram"
  s_email:string='example2@gmail.com'
    ngOnInit() {
    }
    display(data:any){
  alert(data.form.controls.uname.value)
  this.s_id = data.form.controls.s_id.value
  this.s_name = data.form.controls.s_name.value
  this.s_phno = data.form.controls.s_phno.value
  this.s_address = data.form.controls.s_address.value
  this.s_email = data.form.controls.s_email.value
  console.log(data)
    }
  }
