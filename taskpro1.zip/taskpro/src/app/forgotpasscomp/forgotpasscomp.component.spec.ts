import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotpasscompComponent } from './forgotpasscomp.component';

describe('ForgotpasscompComponent', () => {
  let component: ForgotpasscompComponent;
  let fixture: ComponentFixture<ForgotpasscompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotpasscompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotpasscompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
