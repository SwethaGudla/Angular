import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgotpasscomp',
  templateUrl: './forgotpasscomp.component.html',
  styleUrls: ['./forgotpasscomp.component.css']
})
export class ForgotpasscompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
