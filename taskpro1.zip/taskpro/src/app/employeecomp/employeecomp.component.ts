import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeecomp',
  templateUrl: './employeecomp.component.html',
  styleUrls: ['./employeecomp.component.css']
})
export class EmployeecompComponent implements OnInit {

  constructor() { }
  e_id:number=0;
  e_name:string="suraj"
  e_phno:string='suraj@gmai.com';
  e_address:string="Vanasthalipuram"
  e_email:string='example@gmail.com'
    ngOnInit() {
    }
    display(data:any){
  alert(data.form.controls.uname.value)
  this.e_id = data.form.controls.e_id.value
  this.e_name = data.form.controls.e_name.value
  this.e_phno = data.form.controls.e_phno.value
  this.e_address = data.form.controls.e_address.value
  this.e_email = data.form.controls.e_email.value
  console.log(data)
    }
  }
